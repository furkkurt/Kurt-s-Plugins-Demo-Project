/*:
 * @target MZ
 * @plugindesc v1.3.0 Resolution-adaptive pictures & message windows
 * @author Kurts
 *
 * @param Reference Width
 * @type number
 * @desc The screen width your pictures were designed/positioned for
 * @default 1280
 *
 * @param Reference Height
 * @type number
 * @desc The screen height your pictures were designed/positioned for
 * @default 720
 *
 * @help
 * ============================================================================
 * KurtsResolutionPictures  v1.3.0
 * ============================================================================
 *
 * 1) Adjusts picture POSITIONS so they appear at the same relative
 *    screen location regardless of the current game resolution.
 *    Scale is handled by the zoom plugin (KurtsMouseWheelZoom).
 *
 * 2) Scales the message window, name-box and related text so they
 *    occupy the same screen proportion at every resolution.
 */

(() => {
    'use strict';

    const pluginName = 'KurtsResolutionPictures';
    const params = PluginManager.parameters(pluginName);
    const REF_W = Number(params['Reference Width'] || 1280);
    const REF_H = Number(params['Reference Height'] || 720);

    /** Resolution scale factor (height-based for UI) */
    function uiScale() {
        return Graphics.boxHeight / REF_H;
    }

    // =========================================================================
    // 1.  Sprite_Picture position offset
    // =========================================================================
    const _Sprite_Picture_updatePosition =
        Sprite_Picture.prototype.updatePosition;
    Sprite_Picture.prototype.updatePosition = function() {
        _Sprite_Picture_updatePosition.call(this);
        this.x += Math.round((Graphics.width  - REF_W) / 2);
        this.y += Math.round((Graphics.height - REF_H) / 2);
    };

    // =========================================================================
    // 2.  Message window — proportional height & scaled text
    // =========================================================================

    // --- message window rect: scale height to keep same screen % -----------
    const _Scene_Message_messageWindowRect =
        Scene_Message.prototype.messageWindowRect;
    Scene_Message.prototype.messageWindowRect = function() {
        const rect = _Scene_Message_messageWindowRect.call(this);
        const s = uiScale();
        rect.height = Math.round(rect.height * s);
        return rect;
    };

    // --- line height: proportional to resolution ---------------------------
    const _WM_lineHeight = Window_Message.prototype.lineHeight;
    Window_Message.prototype.lineHeight = function() {
        return Math.round(_WM_lineHeight.call(this) * uiScale());
    };

    // --- font size: proportional -------------------------------------------
    const _WM_resetFontSettings = Window_Message.prototype.resetFontSettings;
    Window_Message.prototype.resetFontSettings = function() {
        _WM_resetFontSettings.call(this);
        this.contents.fontSize = Math.round(this.contents.fontSize * uiScale());
    };

    // --- padding: proportional ---------------------------------------------
    const _WM_updatePadding = Window_Message.prototype.updatePadding;
    Window_Message.prototype.updatePadding = function() {
        _WM_updatePadding.call(this);
        this._padding = Math.round(this._padding * uiScale());
    };

    // --- name-box: same scaling --------------------------------------------
    const _WNB_lineHeight = Window_NameBox.prototype.lineHeight;
    Window_NameBox.prototype.lineHeight = function() {
        return Math.round((_WNB_lineHeight || _WM_lineHeight).call(this) * uiScale());
    };

    const _WNB_resetFontSettings = Window_NameBox.prototype.resetFontSettings;
    Window_NameBox.prototype.resetFontSettings = function() {
        _WNB_resetFontSettings.call(this);
        this.contents.fontSize = Math.round(this.contents.fontSize * uiScale());
    };

    const _WNB_updatePadding = Window_NameBox.prototype.updatePadding;
    Window_NameBox.prototype.updatePadding = function() {
        _WNB_updatePadding.call(this);
        this._padding = Math.round(this._padding * uiScale());
    };

    // =========================================================================
    // 3.  Scale \PX[n] and \PY[n] escape codes by resolution
    // =========================================================================
    const _WB_processEscapeCharacter =
        Window_Base.prototype.processEscapeCharacter;
    Window_Base.prototype.processEscapeCharacter = function(code, textState) {
        if (code === 'PX') {
            const px = this.obtainEscapeParam(textState);
            textState.x = Math.round(px * (Graphics.boxWidth / REF_W));
            return;
        }
        if (code === 'PY') {
            const py = this.obtainEscapeParam(textState);
            textState.y = Math.round(py * (Graphics.boxHeight / REF_H));
            return;
        }
        _WB_processEscapeCharacter.call(this, code, textState);
    };

})();
